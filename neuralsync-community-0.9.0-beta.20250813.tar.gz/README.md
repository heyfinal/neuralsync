# NeuralSync (Community Package)

This package contains the data plane (Compose), memory API/worker, and the
AI bus used by NeuralSync. It is a sanitized bundle for distribution; you must
provide your own API keys and wrappers for Claude-Code (Claudes) and codexCLI (codes).

**What it is not:** This is not the enterprise edition and not the home-lab builder.
